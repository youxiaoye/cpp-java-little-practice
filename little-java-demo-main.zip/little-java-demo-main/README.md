#simple access control system
#暑期实训作业
#模拟实现了一个小的门禁系统。
