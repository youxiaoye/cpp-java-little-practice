# 2048game
a little game , the first project in Nankai University 
